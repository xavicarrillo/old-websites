<form action="search.php" method="post">
Tipo de exploit:
<?php
        include ("/inlander/sites/accesodenegado.com/web/htdocs/inc/funciones.php");
        conecta();
	$nul=NULL;
	ImprimeTipos($nul);
?>
<br>
objetivo (demonio, kernel, router, etc.): <input type="text" name="target"><br>
versi�n: <input type="text" name="targetversion"><br>

Sistema:
<?php
        ImprimeSO($nul); //
	echo "<br>arquitectura del SO:";
	ImprimeArquitecturaSO($nul);
?>
<br>

a�o: <input type="text" name="a�o"><br>
<br>
<input type ="submit" name="intro" value="buscar">
<input type ="reset" value="borrar">
</form>
