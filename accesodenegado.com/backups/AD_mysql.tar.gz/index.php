<title>accesodenegado - base de datos Exploits </title>
<link href="../scripts/acceso.css" rel="stylesheet" type="text/css">
<body bgcolor="#999999" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<? include "../cabecera.ad" ?>
  <tr> 
    <td width="30%" bgcolor="#999999">&nbsp;</td>
    <td width="70%" bgcolor="#999999" class="textBold">Buscador de exploits</td>
    <td bgcolor="#999999"><img src="../ima/logoweb2.gif" width="119" height="43"></td>
  </tr>
  <tr> 
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999" class="text">
	  <form action="search.php" method="post">
	
	    <table width="0%" border="0" cellspacing="0" cellpadding="0">
          <tr class="text"> 
            <td>Tipo de exploit: </td>
            <td> 
              <?php
        include ("/inlander/sites/accesodenegado.com/web/htdocs/inc/funciones.php");
        conecta();
	$nul=NULL;
	ImprimeTipos($nul);
?>
            </td>
          </tr>
          <tr class="text"> 
            <td>objetivo (demonio, kernel, router, etc.):</td>
            <td> <input type="text" name="target"></td>
          </tr>
          <tr class="text"> 
            <td>versi�n:</td>
            <td> <input type="text" name="targetversion"></td>
          </tr>
          <tr class="text"> 
            <td>Sistema:</td>
            <td> 
              <?php
        ImprimeSO($nul); //
		?>
            </td>
          </tr>
          <tr class="text">
            <td>Arquitectura del so:</td>
            <td>
              <?php
	ImprimeArquitecturaSO($nul);
			?>
            </td>
          </tr>
          <tr class="text"> 
            <td>a�o: </td>
            <td> <input name="a&ntilde;o" type="text"></td>
          </tr>
          <tr class="text"> 
            <td> <input type ="submit" name="intro" value="buscar"> <input name="reset" type ="reset" value="borrar"></td>
            <td>&nbsp;</td>
          </tr>
        </table>
</form>

	
	
	</td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
  <tr> 
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999" class="text">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
</table>


