<title>accesodenegado - base de datos Exploits</title>
<link href="../scripts/acceso.css" rel="stylesheet" type="text/css">
<script src="../scripts/accesodenegado.js"></script>
<body bgcolor="#999999" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<? include "../cabecera.ad" ?>
  <tr> 
    <td width="30%" bgcolor="#999999">
      <?php
        include ("/inlander/sites/accesodenegado.com/web/htdocs/inc/funciones.php");
        conecta();
	$exploit=DevuelveDatosExploit($idexploit);
	?>
    </td>
    <td width="70%" bgcolor="#999999" class="textBold">Modificador de exploits</td>
    <td bgcolor="#999999"><img src="../ima/logoweb2.gif" width="119" height="43"></td>
  </tr>
  <tr> 
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999" class="text">
<form ACTION="meter_exploit.php" METHOD=POST>
        <table width="0%" border="0" cellpadding="0" cellspacing="0">
          <tr class="text"> 
            <td>Tipo de exploit:</td>
            <td><? echo
        ImprimeTipos($exploit[11]);
		?></td>
          </tr>
          <tr class="text"> 
            <td>objetivo (demonio,etc.)</td>
            <td><? echo "<input type=text name=target value=$exploit[9]>"; ?></td>
          </tr>
          <tr class="text"> 
            <td>versi�n del objetivo:</td>
            <td><? echo "<input type=text name=targetversion value=$exploit[10]>"; ?></td>
          </tr>
          <tr class="text"> 
            <td>Remoto: </td>
            <td> 
              <? ImprimeRemoto ($exploit[12]); //1=no ?>
            </td>
          </tr>
          <tr class="text"> 
            <td>SO: </td>
            <td> 
              <? ImprimeSO($exploit[3]); ?>
            </td>
          </tr>
          <tr class="text"> 
            <td>versi�n del SO:</td>
            <td><? echo "<input type=text name=versionSO value=$exploit[7]>"; ?></td>
          </tr>
          <tr class="text"> 
            <td>arquitectura del SO:</td>
            <td> 
              <? ImprimeArquitecturaSO($exploit[8]); ?>
            </td>
          </tr>
          <tr class="text"> 
            <td>mes:</td>
            <td><? echo "<input type=text name=mes value=$exploit[1]>"; ?></td>
          </tr>
          <tr class="text"> 
            <td>a�o: </td>
            <td><? echo "<input type=text name=a�o value=$exploit[2]>"; ?></td>
          </tr>
          <tr class="text"> 
            <td>lenguaje: </td>
            <td> 
              <?
	 ImprimeLenguaje($exploit[4]);
	 $url=$exploit[6];
	 $comentario=$exploit[5];
	 ?>
            </td>
          </tr>
          <tr class="text"> 
            <td>exploit: </td>
            <td><? echo "<a class=linksblancs href=http://www.accesodenegado.com$exploit[6]>$exploit[6]</a>
		       <a class=linksblancs href=# onclick=\"window.open(browse.php?idexploit=$idexploit);\">modificar</a>
		<input type=hidden name=idexploit value=$idexploit><br>
		<input type=hidden name=fitxer value=$url>"; ?></td>
		
          </tr>
          <tr class="text"> 
            <td>comentario:</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        <br>
        <? echo "<textarea rows=10 name=comentario cols=70>$comentario</textarea>"; ?><br>
          <input type="hidden" name="update" value="0">
          <input type ="submit" name="intro" value="introducir">
          
        <input type ="reset" value="restaurar">
 
</form>
	
	
	</td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
  <tr> 
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999" class="text">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
</table>


