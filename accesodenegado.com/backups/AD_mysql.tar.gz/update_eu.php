
<form ACTION="meter_exploit.php" METHOD=POST>
<?php
        include ("/inlander/sites/accesodenegado.com/web/htdocs/inc/funciones.php");
        conecta();
	$exploit=DevuelveDatosExploit($idexploit);
	?>
	
        
  <p>&nbsp;</p>
  <p>Tipo de exploit: <? echo
        ImprimeTipos($exploit[11]);
		?> <br>
    objetivo (demonio,etc.): <? echo "<input type=text name=target value=$exploit[9]>"; ?> 
    <br>
    versi�n del objetivo: <? echo "<input type=text name=targetversion value=$exploit[10]>"; ?> 
    <br>
    Remoto: 
    <? ImprimeRemoto ($exploit[12]); //1=no ?>
    <br>
    SO: 
    <? ImprimeSO($exploit[3]); ?>
    <br>
    versi�n del SO: <? echo "<input type=text name=versionSO value=$exploit[7]>"; ?> 
    <br>
    arquitectura del SO: 
    <? ImprimeArquitecturaSO($exploit[8]); ?>
    <br>
    mes: <? echo "<input type=text name=mes value=$exploit[1]>"; ?> <br>
    a�o: <? echo "<input type=text name=a�o value=$exploit[2]>"; ?> <br>
    lenguaje: 
    <?
	 ImprimeLenguaje($exploit[4]);
	 $url=$exploit[6];
	 $comentario=$exploit[5];
	 ?>
    <br>
    exploit:<? echo "<a class=linksblancs href=http://www.accesodenegado.com$exploit[6]>$exploit[6]</a>
		<a class=linksblancs href=browse.php?idexploit=$idexploit>modificar </a>
		<input type=hidden name=idexploit value=$idexploit><br>
		<input type=hidden name=fitxer value=$url>"; ?> <br>
    comentario: <br>
    <? echo "<textarea rows=10 name=comentario cols=70>$comentario</textarea>"; ?> 
  </p>
  <p>&nbsp;</p>
  <table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <p><br>
    <br>
    <input type="hidden" name="update" value="0">
    <input type ="submit" name="intro" value="introducir">
    <input type ="reset" value="borrar">
  </p>
</form>

