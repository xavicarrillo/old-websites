
        <script language=javascript>
                function confirmar() {
                        return confirm("�est� seguro?");
                }
        </script>

<?php

//inicializamos variables para la paginaci�n de la busqueda
if (!isset ($siguientes)) { $inicio=0; $siguientes=4; }
if (!isset($exploitsMostrats)) $exploitsMostrats=$siguientes;

include ("/inlander/sites/accesodenegado.com/web/htdocs/inc/funciones.php");
conecta();

$query="select * from exploits where idexploit > 0" or die (mysql_error());

if ($target) $query .=" and target like '%$target%'";
if ($targetversion) $query .=" and targetversion ='$targetversion'";
if ($idSO) $query .=" and idSO='$idSO'";
if ($idarquitectura) $query .=" and idarquitectura='$idarquitectura'";
if ($a�o) $query .=" and a�o like '%$a�o%'";
if ($tipo) $query .=" and tipo like '%$tipo%'";

$query_sin_limit=mysql_query($query) or die (mysql_error());
$total=mysql_num_rows($query_sin_limit);
if ($total==0) die ("<br><center>no hay ning�n resultado<br><a href=\"index.php\">volver</a>");

$query .=" limit $inicio,$siguientes";
$exploits=mysql_query($query) or die (mysql_error());
while ($exploit=mysql_fetch_row($exploits)) {

        $idexploit=$exploit[0];
        $mes=$exploit[1];
	$a�o=$exploit[2];
        $idSO=$exploit[3];
        $idlenguaje=$exploit[4];
        $comentario=$exploit[5];
        $url=$exploit[6];
        $versionSO=$exploit[7];
        $idarquitectura=$exploit[8];
        $target=$exploit[9];
        $targetversion=$exploit[10];
        $tipo=$exploit[11];
        $remoto=$exploit[12];

	$SO=queSO($idSO);
	$lenguaje=QueLenguaje($idlenguaje);
	$arquitectura=QueArquitectura($idarquitectura);
	echo "
		$target $targetversion<br>
		$SO $versionSO <i>$arquitectura</i><BR>
		<a href=\"update.php?idexploit=$idexploit\">modificar </a>
		<a href=\"delete.php?idexploit=$idexploit&url=$url\" onClick=\"return confirmar()\"> |  borrar</a>
		<br>

		lenguaje: $lenguaje<br>
		exploit: <a href=\"http://www.accesodenegado.com$url\">$url</a><br>
	";

	if ($a�o) echo "fecha: $mes $a�o<br>";
	echo "remoto: "; if ($remoto==0) echo "<td> s� <br>"; else echo "<td>no<br>";
	if ($comentario) echo "<br>comentario:<br>$comentario<br><br>";
	echo "<hr>";
}
$inicio=$inicio+$siguientes;
ImprimeFooterSiguientes ($total,$inicio,$siguientes,$exploitsMostrats);

?>
