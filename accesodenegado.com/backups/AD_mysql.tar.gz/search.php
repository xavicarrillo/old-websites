<title>accesodenegado - base de datos Exploits</title>
<script src="../scripts/accesodenegado.js"></script>
<link href="../scripts/acceso.css" rel="stylesheet" type="text/css">
<body bgcolor="#999999" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<? include "../cabecera.ad" ?>
  <tr> 
    <td width="30%" bgcolor="#999999">&nbsp;</td>
    <td width="70%" bgcolor="#999999" class="textBold">Resultados de la b&uacute;squeda</td>
    <td bgcolor="#999999"><img src="../ima/logoweb2.gif" width="119" height="43"></td>
  </tr>
  <tr> 
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999" class="text">
      <?php

//inicializamos variables para la paginaci�n de la busqueda
if (!isset ($siguientes)) { $inicio=0; $siguientes=4; }
if (!isset($exploitsMostrats)) $exploitsMostrats=$siguientes;

include ("/inlander/sites/accesodenegado.com/web/htdocs/inc/funciones.php");
conecta();

$query="select * from exploits where idexploit > 0" or die (mysql_error());

if ($target) $query .=" and target like '%$target%'";
if ($targetversion) $query .=" and targetversion ='$targetversion'";
if ($idSO) $query .=" and idSO='$idSO'";
if ($idarquitectura) $query .=" and idarquitectura='$idarquitectura'";
if ($a�o) $query .=" and a�o like '%$a�o%'";
if ($tipo) $query .=" and tipo like '%$tipo%'";

$query_sin_limit=mysql_query($query) or die (mysql_error());
$total=mysql_num_rows($query_sin_limit);
if ($total==0) die ("<br><center>no hay ning�n resultado<br><a class=linksblancs href=\"index.php\">volver</a>");

$query .=" limit $inicio,$siguientes";
$exploits=mysql_query($query) or die (mysql_error());
while ($exploit=mysql_fetch_row($exploits)) {

        $idexploit=$exploit[0];
        $mes=$exploit[1];
	$a�o=$exploit[2];
        $idSO=$exploit[3];
        $idlenguaje=$exploit[4];
        $comentario=$exploit[5];
        $url=$exploit[6];
        $versionSO=$exploit[7];
        $idarquitectura=$exploit[8];
        $target=$exploit[9];
        $targetversion=$exploit[10];
        $tipo=$exploit[11];
        $remoto=$exploit[12];
	$LastModified=$exploit[13];

	$SO=queSO($idSO);
	$lenguaje=QueLenguaje($idlenguaje);
	$arquitectura=QueArquitectura($idarquitectura);
	echo "<table width=50% border=0 cellspacing=0 cellpadding=0>
  <tr> 
    <td class=text>$target $targetversion</td>
  </tr>
  <tr> 
    <td class=text>$SO $versionSO <i>$arquitectura</i></td>
  </tr>
  <tr> 
    <td class=text><a class=linksblancs href=\"update.php?idexploit=$idexploit\">modificar </a> <a class=linksblancs href=\"delete.php?idexploit=$idexploit&url=$url\" onClick=\"return confirmar()\"> |  borrar</a></td>
  </tr>
  <tr> 
    <td class=text>lenguaje: $lenguaje</td>
  </tr>
  <tr> 
    <td class=text>exploit: <a class=linksblancs href=\"http://www.accesodenegado.com$url\">$url</a></td>
  </tr>
  <tr>";
  
	if ($a�o) echo "<td class=text>fecha: $mes $a�o</td></tr><tr> ";
	echo "<td class=text>remoto: "; if ($remoto==0) echo "s� </td>"; else echo "no</td>";
	echo "<tr><td class=text>�ltima actualizaci�n: $LastModified<br></td></tr>";
	if ($comentario) echo "</tr><tr><td class=text>comentario: </td>";
	echo " </tr><tr><td class=text><pre>$comentario</pre></td></tr></table><br><br>";

}
$inicio=$inicio+$siguientes;
ImprimeFooterSiguientes ($total,$inicio,$siguientes,$exploitsMostrats);

?>
    </td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
  <tr> 
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999" class="text">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
</table>


